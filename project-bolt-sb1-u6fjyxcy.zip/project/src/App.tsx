import React, { useState } from 'react';
import { ShoppingCart, Truck, Leaf } from 'lucide-react';
import Navbar from './components/Navbar';
import ProductGrid from './components/ProductGrid';
import Cart from './components/Cart';
import { Product } from './types';

function App() {
  const [activeCategory, setActiveCategory] = useState('vegetables');
  const [cart, setCart] = useState<Product[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const addToCart = (product: Product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (productId: string) => {
    setCart(cart.filter(item => item.id !== productId));
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        activeCategory={activeCategory} 
        setActiveCategory={setActiveCategory}
        cartItemCount={cart.length}
        onCartClick={() => setIsCartOpen(true)}
      />
      
      <main className="container mx-auto px-4 py-8">
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-2">
            <Leaf className="text-green-500" />
            <h1 className="text-3xl font-bold text-gray-800">K-Kart Fresh</h1>
          </div>
          <div className="flex items-center space-x-2 text-gray-600">
            <Truck />
            <span>Free delivery on orders above ₹500</span>
          </div>
        </div>

        <ProductGrid 
          category={activeCategory} 
          onAddToCart={addToCart}
        />
      </main>

      <Cart 
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        onRemoveItem={removeFromCart}
      />
    </div>
  );
}

export default App;