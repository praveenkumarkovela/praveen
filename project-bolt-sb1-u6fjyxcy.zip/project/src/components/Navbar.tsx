import React from 'react';
import { ShoppingCart } from 'lucide-react';

interface NavbarProps {
  activeCategory: string;
  setActiveCategory: (category: string) => void;
  cartItemCount: number;
  onCartClick: () => void;
}

const categories = [
  { id: 'vegetables', name: 'Vegetables' },
  { id: 'fruits', name: 'Fruits' },
  { id: 'nonveg', name: 'Non-Veg' },
  { id: 'seafood', name: 'Sea Food' },
];

const Navbar: React.FC<NavbarProps> = ({ 
  activeCategory, 
  setActiveCategory, 
  cartItemCount,
  onCartClick 
}) => {
  return (
    <nav className="bg-white shadow-lg">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <div className="flex space-x-4">
            {categories.map((category) => (
              <button
                key={category.id}
                onClick={() => setActiveCategory(category.id)}
                className={`px-4 py-2 rounded-md transition-colors ${
                  activeCategory === category.id
                    ? 'bg-green-500 text-white'
                    : 'text-gray-600 hover:bg-green-50'
                }`}
              >
                {category.name}
              </button>
            ))}
          </div>
          
          <button 
            onClick={onCartClick}
            className="relative p-2 text-gray-600 hover:text-green-500"
          >
            <ShoppingCart size={24} />
            {cartItemCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {cartItemCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;